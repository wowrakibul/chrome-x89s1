
## Color-Zilla

Color-zilla is a Google plugin that can detect color codes in online pages and save them to the web browser's local storage.

- Download or clone the repository from the github URL below : https://github.com/Deshan555/Color-Picker.git
- If you downloaded all codes as zip files, unzip the basic codes.
- open Google Chrome and go to "more tools -> extensions".
- Open Google Chrome in developer mode and pick the load unpacked option.
- After that, you can pick the folder you previously unpacked or cloned.
- If you followed all of the procedures successfully, the extension will automatically launch in Chrome.

![screen-shot](https://github.com/Deshan555/Color-Picker/blob/master/app.png)
